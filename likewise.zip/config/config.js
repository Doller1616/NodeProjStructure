module.exports = { 
    jwtSecretKey: "LikeWise",

}
